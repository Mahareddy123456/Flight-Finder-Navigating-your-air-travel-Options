# Azure Bot Service

[![GitHub code size in bytes](https://img.shields.io/github/languages/code-size/akshatvg/Azure-Bot-Service?logo=github&style=social)](https://github.com/akshatvg/) [![GitHub last commit](https://img.shields.io/github/last-commit/akshatvg/Azure-Bot-Service?style=social&logo=git)](https://github.com/akshatvg/) [![GitHub stars](https://img.shields.io/github/stars/akshatvg/Azure-Bot-Service?style=social)](https://github.com/akshatvg/Azure-Bot-Service/stargazers) [![GitHub forks](https://img.shields.io/github/forks/akshatvg/Azure-Bot-Service?style=social&logo=git)](https://github.com/akshatvg/Azure-Bot-Service/network)

Learning how to make a Flight Booking chatbot using the Azure Bot Service.

<p align="center">
<a href="http://akshatvg-shopping-bot.azurewebsites.net/api/messages">
<img src="https://azure.microsoft.com/svghandler/bot-service?width=600&height=315" height="120px" alt="Azure-Bot-Service Logo"/>
</a>
</p>

![Generic badge](https://img.shields.io/badge/Flight_Booking-Bot-orange) 

## API Link

- [https://akshatvg-shopping-bot.azurewebsites.net/api/messages](https://akshatvg-shopping-bot.azurewebsites.net/api/messages)

## Requirements

[![GitHub top language](https://img.shields.io/github/languages/top/akshatvg/Azure-Bot-Service?logo=javascript&style=social)](https://github.com/akshatvg/)

The source code of this project is written in **`Node.js`**. So, you will require Node.js to run the project.

## Instructions
- Install modules

    ```bash
    npm install
    ```
- Run the bot

    ```bash
    npm start
    ```

## Testing the bot using Bot Framework Emulator

[Bot Framework Emulator](https://github.com/microsoft/botframework-emulator) is a desktop application that allows bot developers to test and debug their bots on localhost or running remotely through a tunnel.

- Install the Bot Framework Emulator version 4.9.0 or greater from [here](https://github.com/Microsoft/BotFramework-Emulator/releases)

### Connect to the bot using Bot Framework Emulator

- Launch Bot Framework Emulator
- File -> Open Bot
- Enter a Bot URL of `http://localhost:3978/api/messages`

## Links to Refer
- [Bot Framework Documentation](https://docs.botframework.com)
- [Bot Basics](https://docs.microsoft.com/azure/bot-service/bot-builder-basics?view=azure-bot-service-4.0)
- [Dialogs](https://docs.microsoft.com/en-us/azure/bot-service/bot-builder-concept-dialog?view=azure-bot-service-4.0)
- [Gathering Input Using Prompts](https://docs.microsoft.com/en-us/azure/bot-service/bot-builder-prompts?view=azure-bot-service-4.0&tabs=javascript)
- [Activity processing](https://docs.microsoft.com/en-us/azure/bot-service/bot-builder-concept-activity-processing?view=azure-bot-service-4.0)
- [Azure Bot Service Introduction](https://docs.microsoft.com/azure/bot-service/bot-service-overview-introduction?view=azure-bot-service-4.0)
- [Azure Bot Service Documentation](https://docs.microsoft.com/azure/bot-service/?view=azure-bot-service-4.0)
- [Azure CLI](https://docs.microsoft.com/cli/azure/?view=azure-cli-latest)
- [Azure Portal](https://portal.azure.com)
- [Language Understanding using LUIS](https://docs.microsoft.com/en-us/azure/cognitive-services/luis/)
- [Channels and Bot Connector Service](https://docs.microsoft.com/en-us/azure/bot-service/bot-concepts?view=azure-bot-service-4.0)
- [Restify](https://www.npmjs.com/package/restify)
- [dotenv](https://www.npmjs.com/package/dotenv)

## Need help?
Feel free to contact me via [Facebook](https://www.facebook.com/akshatvg).

Invite me to connect on [LinkedIn](https://www.linkedin.com/in/akshatvg/).

[![Facebook](https://img.shields.io/badge/Facebook-add-blue.svg?logo=facebook&logoColor=white)](https://www.facebook.com/akshatvg) [![Quora](https://img.shields.io/badge/Quora-ask-red.svg?logo=quora)](https://www.quora.com/profile/Akshat-Gupta-279) [![Instagram](https://img.shields.io/badge/Instagram-follow-purple.svg?logo=instagram&logoColor=white)](https://www.instagram.com/akshatvg/) [![Snapchat](https://img.shields.io/badge/Snapchat-add-yellow.svg?logo=snapchat&logoColor=white)](https://www.snapchat.com/add/akshatvg) [![Medium](https://img.shields.io/badge/Medium-follow-black.svg?logo=medium&logoColor=white)](https://medium.com/@akshatvg)


```bash



 _____ _                 _     __   __            
|_   _| |               | |    \ \ / /            
  | | | |__   __ _ _ __ | | __  \ V /___  _   _   
  | | | '_ \ / _` | '_ \| |/ /   \ // _ \| | | |  
  | | | | | | (_| | | | |   <    | | (_) | |_| |  
  \_/ |_| |_|\__,_|_| |_|_|\_\   \_/\___/ \__,_|  
                                                  
                                                  
______                                            
|  ___|                                           
| |_ ___  _ __                                    
|  _/ _ \| '__|                                   
| || (_) | |                                      
\_| \___/|_|                                      
                                                  
                                                  
______      _               _   _               _ 
| ___ \    (_)             | | | |             | |
| |_/ / ___ _ _ __   __ _  | |_| | ___ _ __ ___| |
| ___ \/ _ \ | '_ \ / _` | |  _  |/ _ \ '__/ _ \ |
| |_/ /  __/ | | | | (_| | | | | |  __/ | |  __/_|
\____/ \___|_|_| |_|\__, | \_| |_/\___|_|  \___(_)
                     __/ |                        
                    |___/                         

 


```

## License

**MIT &copy; [Akshat Gupta](https://github.com/akshatvg/Azure-Bot-Service/blob/master/LICENSE)**

[![GitHub license](https://img.shields.io/github/license/akshatvg/Azure-Bot-Service?style=social&logo=github)](https://github.com/akshatvg/Azure-Bot-Service/blob/master/LICENSE) [![Twitter Follow](https://img.shields.io/twitter/follow/akshatvg?style=social)](https://twitter.com/akshatvg)

---------

```javascript

if (youEnjoyed) {
    starThisRepository();
}

```

-----------

